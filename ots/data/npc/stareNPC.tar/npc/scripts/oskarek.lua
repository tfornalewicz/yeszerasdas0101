-- === REV: 01        DATE: 26 Jan 2017     By: W     Tag: Q1*

local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)
local talkState = {}

function onCreatureAppear(cid)     npcHandler:onCreatureAppear(cid)     end
function onCreatureDisappear(cid)     npcHandler:onCreatureDisappear(cid)     end
function onCreatureSay(cid, type, msg)     npcHandler:onCreatureSay(cid, type, msg)     end
function onThink()     npcHandler:onThink()     end

local voices = {
  {text = 'XDDDDDDDDDDD Polecam ten styl zycia'},
  {text = 'W0 XDDDD'},
{text = 'LEGIA MISTRZEM POLSKI!'},
{text = 'JE*** IKER !'},
{text = 'KUCHARCZYK XDDDDDD'},
  {text = 'HALA MADRID ! RONALDO !'} }

function  creatureSayCallback(cid, type, msg)
   if(not npcHandler:isFocused(cid)) then
  return false
end

  local talkUser = NPCHANDLER_CONVBEHAVIOR == CONVERSATION_DEFAULT and 0 or cid
  local player = Player(cid)
  -- *Q1* Begin
  -- ============= Bilety na mecz ================= 

   if msgcontains(msg,"zeruj") then
      player:setStorageValue(11041, 2)
      selfSay('wyzerowane',cid)
   end

   if (msgcontains(msg,"yes") or msgcontains(msg,"tak")) then
      if player:getStorageValue(11041) < 1 and npcHandler.topic[cid] == 1 then
         player:setStorageValue(11041,1)
         selfSay('XDD X  XD X DD X X  X  X X X DD X X  X XD D XD  XD  XDDD    X X D XD X  X X X X   D X  XD DD  X X DDD D D XDD DD X XDD   D X  XD    XDD X  X  XDD D X DDD   DD X D X X DD X X  X X  X  X X X    XDD X DDD D XD X  X X X X DDD  XDD  XD  XD X X  X X.',cid)
         selfSay('XD   X XD D XD X  X X  X D XD  XD X X  X X   D X  XD   XDD  X X X D XD X  X X X X DDD D X X.',cid)
      end      
   elseif (msgcontains(msg,"mecz") or msgcontains(msg,"legia")) then

      if player:getStorageValue(11041) < 1 then
         selfSay('XD XXXX,  D XD DXD DDXXDD  DD XX XD XDXX X DD  XX XXX DXDX  DX XD  XDXX X DDX XX X DDXXDD  XD XDXX X  XDDX XDX DDXX DXDD XXX DDXX X DXX XDXX  DDD DX XDX  XX  DDXX XD DXXX XDX XD XDXX  DD XX  DXXX XX XDXX X D DXDD.',cid)
         npcHandler.topic[cid] = 1
      end
  -- ============= MISJA TRUDNE POCZATKI ================= 
      
   elseif msgcontains(msg,"bilet") and player:getStorageValue(11041) == 2 then
      player:setStorageValue(11041,3)
      selfSay('XDD  XXX XXD DD XX X  XX  D XD DXD  DD XD DD  DDXX XD DXD XD DDXX  XXX D XD DXX XX DDD DX DDD XDD DXDD DDXXDD  XDD X DDXX  XXX DDD DXXX XX X  DDX DDD.',cid)
      selfSay('DX DDD  XX  DD DDD DDXX X XXX DDXX  DXD DDD XDX DDXX DXDD XXX D XD DXDX  DDXX  DD DDD XDDD X XDDD  XDXX DDD DXX DXD XX  XDDD XD DXD  DXDX XXXX DXDX X XXX DDXX.',cid)
   end
  -- *Q1* End
  return true
end

npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new()) 
