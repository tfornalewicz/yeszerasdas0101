local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)
local talkState = {}

function onCreatureAppear(cid)     npcHandler:onCreatureAppear(cid)     end
function onCreatureDisappear(cid)     npcHandler:onCreatureDisappear(cid)     end
function onCreatureSay(cid, type, msg)     npcHandler:onCreatureSay(cid, type, msg)     end
function onThink()     npcHandler:onThink()     end
function  creatureSayCallback(cid, type, msg)
   if(not npcHandler:isFocused(cid)) then
  return false
end

  local talkUser = NPCHANDLER_CONVBEHAVIOR == CONVERSATION_DEFAULT and 0 or cid
  local player = Player(cid)
  
  if msgcontains(msg,"luk") then
    if player:getItemCount(2071) > 0 and player:getItemCount(5922) > 2 and player:getItemCount(2744) > 0 then
        player:addItem(10295,1) -- dostaje musician bow
        player:removeItem(2071,1) -- zabieram harfe
        player:removeItem(5922,3) -- zabieram 3 holyorchidy
        player:removeItem(2744,1) -- zabieram red rose
        selfSay('Trzymaj ten specjalny luk, stworzony dzieki magii elfow.',cid)
    else
        selfSay('Aby wytworzyc luk potrzebuje hardy, 3 holy orchidow oraz czerwonej rozy',cid)
    end
  end

  return true
end

npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new()) 
